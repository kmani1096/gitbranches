package com.codespy.airline.exception;

import org.springframework.security.core.AuthenticationException;

public class OAuth2Exception extends AuthenticationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OAuth2Exception(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
