/**
 * 
 */
package com.codespy.airline.enums;

/**
 * @author CodeSpy
 *
 */
public enum SocialLogin {
	 GOOGLE
}
